/*
 * factorial.c
 *
 *  Created on: Jan 14, 2011
 *      Author: sgehwolf
 */
#include <stdio.h>

long factorial_rec(int n) {
	if (n == 1 || n == 0) {
		return 1;
	}
	else
		return n * factorial_rec(n - 1);
}

long factorial_iter(int n) {
	if (n == 1 || n == 0) {
		return 1;
	}
	long fact = 1;
	while (n > 0) {
		fact *= n;
		n--;
	}
	return fact;
}

int main(void) {
	printf("factorial recursive:\t%ld\n", factorial_rec(5));
	printf("factorial iterative:\t%ld\n", factorial_iter(5));
	return 0;
}
